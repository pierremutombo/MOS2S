#!/usr/bin/env python3

import requests
import os
import pathlib
import dateutil.parser as dp
#from mos2s.opendatasensor.const import *
from mos2s.core.const import NUMBER_OF_SAVED_METRICS, ODS_URL_BASE_GET_DATA

class IterOpenDataSensor(type):
	"""
	This is a class to make the OpenDataSensor class "Iterable"
	"""

	def __iter__(cls):
		return iter(cls._allSensors)

class OpenDataSensor(metaclass=IterOpenDataSensor):

	"""	The OPenDataSensor class

	The OpenDataSensor class represents the Open Data sensor from OK Lab Stuttgart.
	https://luftdaten.info/en/home-en/
	https://github.com/opendata-stuttgart/meta/wiki/APIs

	One OpenDataSensor instance is created for every sensor with sensor_type=2. 
	The required information to create an OpenDataSensor instance is
	in the SENSORS array in mos2s.core.sensors

	Attributes:
		scope_id: The scope_id which this sensor belongs to in the IDLab IoT stack.
		thing_id: The thing_id that represents this sensor in the IDLab IoT stack.
		sensor_id: The sensor_id that represents this sensor in the OpenDataServer.
		country: The country where the sensor is. 
		location: The GPS coordinates where the sensor is. 
		current_waether: The current metrics for weather (temparture and humidity)*.
		current_pollution: The current metrics for pollution (PM2.5 and PM10)*.
		timestamp: The timestamp for the gotten metrics.
		history: Array with the last metrics.

	* Since the metrics are not completely defined, I'm asumming that the project
	is going to have sensors for weather and pollution. Besides, I'm calling
	sensor the entire unit, i.e., the OpenDataSensor is composed by THE NodeMCU unit 
	(esp8266), the air pollution sensor (SDS011) and the weather sensor (DHT22).
	"""

	# An array to store all AirVisualSensors
	_allSensors = []

	def __init__(self,sensor):
		self._allSensors.append(self)
		self.thing_id = sensor['thing_id']
		self.scope_id = sensor['scope_id']
		self.sensor_id = sensor['sensor_id']
		self.country = ''
		self.location = {}
		self.current_weather = {}
		self.current_pollution = {}
		self.timestamp = ''
		self.history = []

	def __str__(self):
		return "thing: {}, scope: {}".format(self.thing_id, self.scope_id)

	def print_sensor_attributes(self):
		attr = vars(self)
		print("Attributes for thing {}".format(self.thing_id))
		for i in attr:
			print("{} : {}".format(i, attr[i]))

	def get_sensor_metrics(self):
		"""
		Get the metrics for an OpenDataSensor instance.

		Parameters
		----------
		sensor: OpenDataSensor
			The sensor instance whose metrics are going to be gotten.
		Returns
		-------
		data: list
			The metrics for the sensor instance.
		"""

		data = []

		url = ODS_URL_BASE_GET_DATA+self.sensor_id['weather_ID']+'/'
		response = requests.request("GET", url)
		if not response:
			logging.warning("Current weather for thing: {} not returned!".format(self.thing_id))
			print("Current weather for thing: {} not returned!".format(self.thing_id))
		else:
			data.append(response.json()[-1])

		url = ODS_URL_BASE_GET_DATA+self.sensor_id['pollution_ID']+'/'
		response = requests.request("GET", url)
		if not response:
			logging.warning("Current pollution for thing: {} not returned!".format(self.thing_id))
			print("Current pollution for thing: {} not returned!".format(self.thing_id))
		else:
			data.append(response.json()[-1])
	
		return data

	def update_metrics(self,query):
		"""
		Update the metrics for an OpenDataSensor instance.
		The current metrics are always the last gotten metrics.

		Parameters
		----------
		sensor: OpenDataSensor
			The sensor instance whose metrics are going to be updated.
		query: List
			The sensor metrics to be updated
		"""

		self.country = ''
		self.location = query[0]['location']
		self.current_weather = query[0]['sensordatavalues']
		self.current_pollution = query[1]['sensordatavalues']
		self.timestamp = query[0]['timestamp']

	def store_metrics(self,query):
		"""
		Store the metrics for an OpenDataSensor instance.

		The idea is if the IoT stack fails, we have some metrics stored
		in this application. The NUMBER_OF_SAVED_METRICS needs to be adjusted
		in order to establish how many metrics are going to be stored.
		All metrics are stored in data-history folder.

		Parameters
		----------
		sensor: OpenDataSensor
			The sensor instance whose metrics are going to be stored.
		query: List
			The sensor metrics to be stored
		"""

		self.history.append(query) 
		data_history_path = os.getcwd()+'/data-history/'+str(self.scope_id)
		pathlib.Path(data_history_path).mkdir(parents=True, exist_ok=True) 

		with open(os.path.join(data_history_path, str(self.thing_id)), 'wt') as f:
			f.write(str(self.history))

		if len(self.history) == NUMBER_OF_SAVED_METRICS:
			self.history = []
		else:
			pass

	def parse_data(self):
		"""
		Put the metrics in the right format to be posted 
		in the IDLab IoT stack.
		The metrics that are posted are the current metrics.

		Parameters
		----------
		sensor: OpenDataSensor
			The sensor instance whose metrics are going to be posted.
		Returns
		-------
		parsed_data: List
			The parsed data in the right format.
		"""

		metrics = {}
		metrics["mos2s.hercules.humidity.rh"] = float(self.current_weather[0]['value'])
		metrics["mos2s.hercules.temperature.celsius"] = float(self.current_weather[1]['value'])
		#metrics["atmosphericpressure.hPa"] = self.current_weather['pr']
		metrics["mos2s.hercules.pm10.ugm3"] = float(self.current_pollution[0]['value'])
		metrics["mos2s.hercules.pm25.ugm3"] = float(self.current_pollution[1]['value'])

		parsed_time = dp.parse(self.timestamp)
		timestamp = parsed_time.timestamp()*1000

		geo_location = {}
		geo_location["geoloc"] = {}
		geo_location["geoloc"]["lat"] = float(self.location['latitude'])
		geo_location["geoloc"]["lng"] = float(self.location['longitude'])

		parsed_data = [int(timestamp),self.thing_id,metrics,geo_location]

		return parsed_data