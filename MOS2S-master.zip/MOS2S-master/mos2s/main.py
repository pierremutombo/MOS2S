#!/usr/bin/env python3

import logging
import pathlib
from mos2s.airvisualsensor.airvisualsensor import AirVisualSensor
from mos2s.opendatasensor.opendatasensor import OpenDataSensor
from mos2s.core.utils import *
from mos2s.core.const import CLIENTS, LOG_FILE, FORMAT
from mos2s.core.sensors import SENSORS
from collections import defaultdict

"""
#
# We make the general core operations in this file.
#
# These operations are: 
#
# 1. Create the sensors,
# 2. Get tokens for all clients
# 3. Refresh tokens for all clients
#
"""

"""
Dict to manage the token for all CLIENTS. 
It contains the access_token and refresh_token for each client.
Initially we have two clients to post data on the IDLab IoT Stack. 
See mos2s.core.const.CLIENTS
"""

token_mgmt = defaultdict(dict)
token_mgmt['mos2s-hercules-1']['access_token'] = ''
token_mgmt['mos2s-hercules-1']['refresh_token'] = ''

# Establish the log format and file
logging.basicConfig(format=FORMAT, filename=LOG_FILE, level=logging.INFO)

# 1. Create sensors
def create_sensors():
	"""
	Create the sensors for the app based on mos2s.core.const.
	It uses the SENSORS array in mos2s.core.const.
	"""

	for sensor in SENSORS:
		if sensor['sensor_type'] == 1:
			AirVisualSensor(sensor)
		#else:
			#OpenDataSensor(sensor)

	#logging.info('Sensors created')


# Get RPT for each group of sensors
def get_all_tokens():
	"""
	Get the token for each client in mos2s.core.const.

	Parameters
	----------
		It uses the CLIENTS array in mos2s.core.const.
	Returns
	-------
	response: json
		The message response if the get RPT token successfully updated.
		Since we need 3 parameters (token, refresh_token and expires_in), we send the entire response
	"""

	for client in CLIENTS:

		response = get_RPT_token(client['CLIENT_ID'])

		if response != '':
			token_mgmt[client['CLIENT_ID']]['access_token'] = response['access_token']
			token_mgmt[client['CLIENT_ID']]['refresh_token'] = response['refresh_token']	 
		else:
			print('RPT for client: {} not goten!'.format(client['CLIENT_ID']))
			# here we can try more times?

	return token_mgmt

# Refresh RPT for each group of sensors
def refresh_all_tokens(token):
	"""
	Refresh the token for each client in mos2s.core.const.

	Parameters
	----------
	token: Dict
		The all client tokens to be refreshed.
	Returns
	-------
	response: Dict
		The all client tokens refreshed.
		Since all the tokens are got at the same time, we always refresh all tokens together.

	"""
	
	for client, token in token.items():

		response = refresh_RPT_token(client,token)

		if response != '':
			token_mgmt[client]['access_token'] = response['access_token']
			token_mgmt[client]['refresh_token'] = response['refresh_token']		 
		else:
			print('RPT for client: {} not refreshed!'.format(client))
			# here we can try more times?

	return token_mgmt
