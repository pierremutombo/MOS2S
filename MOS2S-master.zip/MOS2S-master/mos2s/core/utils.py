#!/usr/bin/env python3

import requests
import json
from requests.auth import HTTPBasicAuth
import logging
from mos2s.core.const import *
from mos2s.airvisualsensor.airvisualsensor import AirVisualSensor

"""
Dict of authstring. 
It contains the Basic Access Authentication hearder for each CLIENT. 
key: value, client: Basic Access Authentication hearder 
Initially we have two clients to post data on the IoT Stack. 
See mos2s.core.const.CLIENTS
"""

authStrings = {}

for client in CLIENTS:
	authStrings[client['CLIENT_ID']] = HTTPBasicAuth(client['CLIENT_ID'],client['CLIENT_SECRET'])

def get_RPT_token(client):
	"""
	Get the RTP token to use the rest API in the IDLab IoT stack.

	Parameters
	----------
	client : str
		The Client ID. See CLIENTS in mos2s.core.const.
	Returns
	-------
	response: json
		The message response if the get RPT token successfully gotten.
		Since we need 3 parameters (token, refresh_token and expires_in), we send the entire response
	"""

	logging.info("Getting RPT for client: {}".format(client))
	authString = authStrings[client]
	response = requests.request("POST", URL_GET_RPT, auth=authString, headers=HEADERS_RPT, data=GET_RTP_PARAMS)

	if response.status_code == 200:
		logging.info('RPT for client: {} gotten!'.format(client))
		return response.json()
	else:
		logging.critical("RPT for client: {} not gotten. Status code: {} Problem: {}".format(client, response.status_code, response.text))
		return ''

def refresh_RPT_token(client,token):
	"""
	Update the RPT to use the rest API in the IDLab IoT stack

	Parameters
	----------
	client : str
		The Client ID. See CLIENTS in mos2s.core.const.
	token: dict
		The token to be refreshed
	Returns
	-------
	response: json
		The message response if the get RPT token successfully gotten.
		Since we need 3 parameters (token, refresh_token and expires_in), we send the entire response
	"""

	logging.info("Updating RPT")
	authString = authStrings[client]
	UPDATE_RTP_FORM_PARAMS['refresh_token'] = token['refresh_token']
	response = requests.request("POST", URL_UPDATE_RPT, auth=authString, headers=HEADERS_RPT, data=UPDATE_RTP_FORM_PARAMS)
	
	if response.status_code == 200:
		logging.info('RPT for client {} updated!'.format(client))
		return response.json()
	else:
		logging.critical("RPT for client: {} not updated. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		return ''

"""

IDLAB-IOT Core API v1.

All the API documentation can be found in:
https://idlab-iot.tengu.io/api/v1/spec/swagger/

This is just the implementation of some core HTTP 
operations supported by this version of the IDLAB-IOT platform.

"""

"""
GENERAL OPERATIONS.
General operations accessible by all users.
"""

def get_context(client,token):
	"""
	Get the current authentication context.

	Parameters
	----------
	client : str
		The Client ID. See CLIENTS in mos2s.core.const.
	token: dict
		Token to establish the authentication context.
	Returns
	-------
	response: json
		The message response if the response is successful.
	"""

	url ='https://idlab-iot.tengu.io/api/v1/context'	
	headers = {'Authorization': 'Bearer '+token[client]['access_token'], 'accept': 'application/json'}
	response = requests.request("GET", url, headers=headers)
	print("Getting context for client: {}".format(client))

	if response.status_code == 200:
		logging.info("Context for client: {} gotten!".format(client))
		return response.json()
	else:
		logging.warning("Context for client: {} not gotten. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		print("Context for client: {} not gotten. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		return ''

def get_context_scopes(client,token):	
	"""
	Get the scopes that are accessible from the current authentication context.

	Parameters
	----------
	client : str
		The Client ID. See CLIENTS in mos2s.core.const.
	token: dict
		Token to establish the authentication context.
	Returns
	-------
	response: json
		The message response if the response is successful.
	"""
		
	url ='https://idlab-iot.tengu.io/api/v1/context/scopes'	
	headers = {'Authorization': 'Bearer '+token[client]['access_token'], 'accept': 'application/json'}
	response = requests.request("GET", url, headers=headers)
	print("Getting context scopes for client: {}".format(client))
	
	if response.status_code == 200:
		logging.info("Context scopes for client: {} gotten!".format(client))
		return response.json()
	else:
		logging.warning("Context scopes for client {} not gotten. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		print("Context scopes for client {} not gotten. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		return ''

def post_ingest(client,data,token,granularity=None):
	"""
	Publish sensor data to the IDLab IoT stack.

	Parameters
	----------
	client : str
		The Client ID. See CLIENTS in mos2s.core.const.
	token: dict
		Token to establish the authentication context.
	data: list
		An array of sensor data input records.
	granularity: str
		format of the timestamp (SECONDS,MILLISENCONDS,MICROSENCONDS, MILLISENCONDS).
	Returns
	-------
	response: json
		The message response if the response is successful.
	"""
	
	if granularity == None:
		granularity = MILLISECONDS

	url = 'https://idlab-iot.tengu.io/api/v1/ingest'
	headers = {'accept': '*/*', 'Content-Type': 'application/json', 'Authorization': 'Bearer '+token[client]['access_token']}
	params = ('ts', granularity)
	response = requests.request("POST", url, headers=headers, data=json.dumps(data))

	if response.status_code == 204:
		logging.info("Data for client: {} successfully posted!".format(client))
		print("Data for client: {} successfully posted!".format(client))
		return response.text
	else:
		logging.critical("Error posting data for client: {}. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		print("Error posting data for client: {}. Status code: {}. Problem: {}".format(client, response.status_code, response.text))
		return response.text