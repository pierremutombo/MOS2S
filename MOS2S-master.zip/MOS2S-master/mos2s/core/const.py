#!/usr/bin/env python3

# Core constants

"""
All these constants are provided for the Iot Stack documentation:
https://idlab-iot.tengu.io/api/v1/docs/security/auth-details/#2-client-as-itself
If they change the API, we need to change these values.
"""
URL_GET_RPT =  'https://idlab-iot.tengu.io/auth/realms/idlab-iot/protocol/openid-connect/token'
GET_RTP_PARAMS = {'grant_type':'urn:ietf:params:oauth:grant-type:uma-ticket', 'audience':'policy-enforcer'}

URL_UPDATE_RPT = 'https://idlab-iot.tengu.io/auth/realms/idlab-iot/protocol/openid-connect/token'
UPDATE_RTP_FORM_PARAMS = {'grant_type':'refresh_token', 'refresh_token':''}

HEADERS_RPT = {'Content-Type': 'application/x-www-form-urlencoded'}

"""
We have 2 groups of sensors. 
The metrics for each group of sensors are posted in the IoT stack using 2 different client accounts
"""
CLIENTS = [
{'CLIENT_ID':"mos2s-hercules-1",'CLIENT_SECRET':"2c5b548c-6951-4a78-af41-f4406f689831"},
{'CLIENT_ID':"mos2s-hercules-2",'CLIENT_SECRET':"ab865c1c-d794-4cf2-afd4-6c695979f112"},
]

"""
We have 3 scopes, one scope for each client and a third one which joins all the metrics.
We only use 2 scopes.
"""
SCOPES = {'other.mos2s.hercules.set1':"mos2s-hercules-1",
'other.mos2s.hercules.set2':"mos2s-hercules-2"}

"""
granularity options in URL post. It indicates de granularity of the timestamp.
By defalut MILISECONDS
"""
SECONDS = 'seconds'
MILLISECONDS = 'milliseconds'
MICROSECONDS = 'microseconds'
NANOSECONDS = 'nanoseconds'

# Path and format for LOG_FILE
LOG_FILE = 'data-history/logs/log.log'
FORMAT = '%(asctime)s %(levelname)s %(message)s '

# Period (in seconds) for looping all the script
PERIOD = 60

# This value is used in the store_metrics method for each class.
NUMBER_OF_SAVED_METRICS = 2

# AirVisualSensor constants

"""
This is the API KEY for AirVisual API.
https://www.airvisual.com/dashboard/api
"""
MY_GET_API_KEY = "vKzHMNdLZWHm7EQuC"

# OpenDataSensor constant

"""
This is the BASE Url to get the metrics
https://github.com/opendata-stuttgart/meta/wiki/APIs#accessing-the-api-data
"""
ODS_URL_BASE_GET_DATA = 'http://api.luftdaten.info/v1/sensor/'
