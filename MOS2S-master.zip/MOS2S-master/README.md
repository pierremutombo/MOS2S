
## Install requirements ##

pip3 install -r requirements.txt

## How to run the app ##

python3 mos2s-runtime.py

## Documentation for this project ##

https://github.com/nelsoncardona/MOS2S/wiki/Home


