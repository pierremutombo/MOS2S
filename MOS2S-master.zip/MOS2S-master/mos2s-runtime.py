#!/usr/bin/env python3

import time
from collections import defaultdict
from mos2s.airvisualsensor.airvisualsensor import AirVisualSensor
from mos2s.opendatasensor.opendatasensor import OpenDataSensor
from mos2s.core.utils import post_ingest
from mos2s.core.const import CLIENTS, PERIOD, SCOPES
from mos2s.main import *

all_data = defaultdict(list)

if __name__ == '__main__':

	create_sensors()
	tokens = get_all_tokens()
	print("Init finished")

	while True:

		# Process the all AirVisualSensors (fancy sensor)
		for sensor in AirVisualSensor:

			data = sensor.get_sensor_metrics()
			sensor.update_metrics(data)
			#sensor.store_metrics(data)
			parsed_data = sensor.parse_data()
			all_data[SCOPES[sensor.scope_id]].append(parsed_data)
			print(parsed_data)
			print('/n')
	
		# Process the all the OpenDataSensors (not fancy sensor)
		#for sensor in OpenDataSensor:

			#data = sensor.get_sensor_metrics()
			#sensor.update_metrics(data)
			#sensor.store_metrics(data)
			#parsed_data = sensor.parse_data()
			#all_data[SCOPES[sensor.scope_id]].append(parsed_data)
	
		# Post all metrics in the IDLAB-IOT Stack.
		# We only do 2 post requests, one for each scope
		print(all_data)
		#for client in CLIENTS:
			#response = post_ingest(client=client['CLIENT_ID'],data=all_data[client['CLIENT_ID']],token=tokens)
			#if response == 'Unauthorized':
				#refresh_all_tokens(tokens)
	
		time.sleep(PERIOD)

	

		


