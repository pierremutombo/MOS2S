#!/bin/sh
#!/usr/bin/env python3
echo Hello World > /home/bae.txt  
python3 test.py
