#!/usr/bin/env python3

import requests
import os
import pathlib
import dateutil.parser as dp
import json 
from mos2s.core.const import NUMBER_OF_SAVED_METRICS, MY_GET_API_KEY

class IterAirVisualSensor(type):
	"""
	This is a class to make the AirVisualSensor class "Iterable"
	"""

	def __iter__(cls):
		return iter(cls._allSensors)

class AirVisualSensor(metaclass=IterAirVisualSensor):

	"""	The AirVisualSensor class

	The AirVisualSensor class represents the Air Visual Pro sensor.
	https://www.airvisual.com/air-quality-monitor

	One AirVisualSensor instance is created for every sensor with sensor_type=1. 
	The required information to create an AirVisualSensor instance is
	in the SENSORS array in mos2s.core.sensors

	Attributes:
		scope_id: The scope_id which this sensor belongs to in the IDLab IoT stack.
		thing_id: The thing_id that represents this sensor in the IDLab IoT stack.
		sensor_url: The url provided by the AirVisual API for this sensor.
		city: The city where the sensor is.
		state: The state where the sensor is. 
		country: The country where the sensor is. 
		location: The GPS coordinates where the sensor is. 
		current_waether: The current metrics for weather (temparture and humidity).
		current_pollution: The current metrics for pollution (aqi)*.
		timestamp: The timestamp for the gotten metrics.
		history: Array with the last metrics.

	* Since I do not have a sensor, I'm not sure if the sensor reports the PM2.5 and PM10 
	with a community account. It is necesarry a sensor to know the exact reported metrics.
	"""

	# An array to store all AirVisualSensors
	_allSensors = []

	def __init__(self,sensor):

		self._allSensors.append(self)
		self.thing_id = sensor['thing_id']
		self.scope_id = sensor['scope_id']
		self.sensor_url = sensor['sensor_url']
		self.city = ''
		self.state = ''
		self.country = ''
		self.location = {}
		self.current_weather = {}
		self.current_pollution = {}
		self.timestamp = ''
		self.history = []

	def __str__(self):
		return "thing: {}, scope: {}".format(self.thing_id, self.scope_id)

	def print_sensor_attributes(self):
		attr = vars(self)
		print("Attributes for thing {}".format(self.thing_id))
		for i in attr:
			print("{} : {}".format(i, attr[i]))

	def get_sensor_metrics(self):
		"""
		Get the metrics for an AirVisualSensor instance.

		Parameters
		----------
		sensor: AirVisualSensor
			The sensor instance whose metrics are going to be gotten.
		Returns
		-------
		data: Dict
			The metrics for the sensor instance.
		"""

		url = self.sensor_url
		querystring = {"key":MY_GET_API_KEY}
		response = requests.request("GET", url, params=querystring)
		data = response.json()
		return data

	def update_metrics(self,query):
		"""
		Update the metrics for an AirVisualSensor instance.
		The current metrics are always the last gotten metrics.

		Parameters
		----------
		sensor: AirVisualSensor
			The sensor instance whose metrics are going to be updated.
		query: Dict
			The sensor metrics to be updated
		"""
		self.current_metrics  = query['current']
		self.timestamp = query['current']['ts']
		#self.weather = query['historical']['hourly']	
		#print("heri",query['historical']['hourly'])	
	

	def store_metrics(self,query):
		"""
		Store the metrics for an AirVisualSensor instance.

		The idea is if the IoT stack fails, we have some metrics stored
		in this application. The NUMBER_OF_SAVED_METRICS needs to be adjusted
		in order to establish how many metrics are going to be stored.
		All metrics are stored in data-history folder.

		Parameters
		----------
		sensor: AirVisualSensor
			The sensor instance whose metrics are going to be stored.
		query: Dict
			The sensor metrics to be stored
		"""

		self.history.append(query) 
		data_history_path = os.getcwd()+'/data-history/'+str(self.scope_id)
		pathlib.Path(data_history_path).mkdir(parents=True, exist_ok=True) 

		with open(os.path.join(data_history_path, str(self.thing_id)), 'wt') as f:
			f.write(str(self.history))

		if len(self.history) == NUMBER_OF_SAVED_METRICS:
			self.history = []
		else:
			pass

	def parse_data(self):
		"""
		Put the metrics in the right format to be posted 
		in the IDLab IoT stack.
		The metrics that are posted are the current metrics.

		Parameters
		----------
		sensor: AirVisualSensor
			The sensor instance whose metrics are going to be posted.
		Returns
		-------
		parsed_data: List
			The parsed data in the right format.
		"""

		metrics = {}
		#metrics["mos2s.hercules.timestamp"] = self.current_metrics['ts']
		metrics["mos2s.hercules.humidity.rh"] = float(self.current_metrics['hm'])
		metrics["mos2s.hercules.temperature.celsius"] = float(self.current_metrics['tp'])
		metrics["mos2s.hercules.PM1"] = float(self.current_metrics['p1'])
		metrics["mos2s.hercules.PM2"] = float(self.current_metrics['p2'])
		metrics["mos2s.hercules.carbonedioxyde.ppm"] = float(self.current_metrics['co'])
		parsed_time = dp.parse(self.timestamp)
		timestamp = parsed_time.timestamp()*1000
		
		parsed_data = [int(timestamp),self.thing_id,metrics]

		return parsed_data
